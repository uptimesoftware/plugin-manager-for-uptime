#!/bin/sh
cd ..
UPTIME_DIR=`pwd`
PHPDIR="$UPTIME_DIR/apache/bin/"
LOADER_DIR="$UPTIME_DIR/plugin_manager/"
cd "$LOADER_DIR"

"$PHPDIR/php" "$LOADER_DIR/load_plugin.php" $1 $2 $3 $4 $5 $6 $7 $8 $9
