<?php /* Smarty version Smarty-3.1.11, created on 2012-09-25 12:17:49
         compiled from ".\UI\header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:25735061d92d06d307-19069595%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6a7aa3846e0d04083dc2a5e3ee529a23269f3637' => 
    array (
      0 => '.\\UI\\header.tpl',
      1 => 1347991879,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '25735061d92d06d307-19069595',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'title' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_5061d92d07e562_04700958',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5061d92d07e562_04700958')) {function content_5061d92d07e562_04700958($_smarty_tpl) {?><!DOCTYPE html>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=80%,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
<link rel="stylesheet" type="text/css" href="uptime-mobile.css" />

<title><?php echo (($tmp = @$_smarty_tpl->tpl_vars['title']->value)===null||$tmp==='' ? "Mobile" : $tmp);?>
</title>
<?php }} ?>