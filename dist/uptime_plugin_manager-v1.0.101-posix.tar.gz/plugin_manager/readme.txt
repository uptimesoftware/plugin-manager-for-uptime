up.time Plugin Manager
-------------------------

Thanks for installing the up.time Plugin manager.

To complete installation, copy and paste the following text to the up.time configuration section:
up.time UI > Config > up.time Configuration:

myportal.custom.tab1.enabled=true
myportal.custom.tab1.name=up.time Plugin Manager
myportal.custom.tab1.URL=http://<HOSTNAME/IP>:9999/plugin_manager/



You can now use the manager by clicking on the My Portal tab in the up.time interface.

Thanks